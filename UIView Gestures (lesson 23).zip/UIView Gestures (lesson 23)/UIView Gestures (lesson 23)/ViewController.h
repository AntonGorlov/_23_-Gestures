//
//  ViewController.h
//  UIView Gestures (lesson 23)
//
//  Created by Anton Gorlov on 28.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

