//
//  ViewController.m
//  UIView Gestures (lesson 23)
//
//  Created by Anton Gorlov on 28.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIGestureRecognizerDelegate>

@property (weak,nonatomic) UIView* testView;
@property (assign, nonatomic) CGFloat testViewScale;
@property (assign, nonatomic) CGFloat testViewRotation;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //соз тап
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc]
                                         initWithTarget:self
                                          action:@selector(handleTap:)];
    
    [self.view addGestureRecognizer:tapGesture];
    
    //соз двойной тап
    
    UITapGestureRecognizer* doubleTapGesture = [[UITapGestureRecognizer alloc]
                                          initWithTarget:self
                                          action:@selector(handleDoubleTap:)];
    
    doubleTapGesture.numberOfTapsRequired = 2; //двойной тап заработал
    [self.view addGestureRecognizer:doubleTapGesture];

    //сделаем ,чтобы "tap" не срабатывал пока не сработает "doubleTap"
    [tapGesture requireGestureRecognizerToFail:doubleTapGesture];
    
     //сделаем "doubleTap" c "doubleTouch"
    
    UITapGestureRecognizer* doubleTapDoubleTouchGesture = [[UITapGestureRecognizer alloc]
                                                initWithTarget:self
                                                action:@selector(handleDoubleTapDoubleTouch:)];
    
    doubleTapDoubleTouchGesture.numberOfTapsRequired = 2;
    doubleTapDoubleTouchGesture.numberOfTouchesRequired = 2;
    
    [self.view addGestureRecognizer:doubleTapDoubleTouchGesture];
    
    
    //соз view
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMidX(self.view.bounds)-50,
                                                            CGRectGetMidY(self.view.bounds)-50, 100, 100)];
    
    
    
    view.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin
                            |UIViewAutoresizingFlexibleRightMargin
                            |UIViewAutoresizingFlexibleTopMargin
                            |UIViewAutoresizingFlexibleBottomMargin;
    
    view.backgroundColor = [self randomColor];
    [self.view addSubview:view];
    self.testView = view;
    
    //создаем зум (Pinch)
    
    UIPinchGestureRecognizer* pinchGesturs = [[UIPinchGestureRecognizer alloc]initWithTarget:self
                                                                                      action:@selector(handlePinch:)];
    
    pinchGesturs.delegate = self;
    [self.view addGestureRecognizer:pinchGesturs];
    
    
    //создаем "Rotation" (крутим прямоугольник)
    
    UIRotationGestureRecognizer* rotationGesture = [[UIRotationGestureRecognizer alloc]initWithTarget:self
                                                                                    action:@selector(handleRotation:)];
    
    rotationGesture.delegate = self;
    [self.view addGestureRecognizer:rotationGesture];
    
    

    
    
}



- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
   
}

#pragma mark - Methods

-(UIColor*) randomColor {
    
    CGFloat r = (float)(arc4random() %256)/255.f;
    CGFloat g = (float)(arc4random() %256)/255.f;
    CGFloat b = (float)(arc4random() %256)/255.f;
    
    return [UIColor colorWithRed:r green:g blue:b alpha:1.f];

}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;

}


#pragma mark - Gesturs

-(void) handleTap:(UITapGestureRecognizer*) tapGesture {
    
    NSLog(@"Tap = %@",NSStringFromCGPoint([tapGesture locationInView:self.view]));
    
    self.testView.backgroundColor = [self randomColor];//при нажатии меняем цвет
    
    
}

-(void) handleDoubleTap:(UITapGestureRecognizer*) tapGesture {
   
    NSLog(@"Double Tap = %@",NSStringFromCGPoint([tapGesture locationInView:self.view]));
    
    
    CGAffineTransform currentTransform = self.testView.transform;//текущий трансформ
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, 1.2f, 1.2f); // увелич. на 1,2
    [UIView animateWithDuration:0.5f
                     animations:^{
                         self.testView.transform = newTransform; //  устанавливаем
                     }];

    self.testViewScale =1.2f;
    
    
    
}

-(void) handleDoubleTapDoubleTouch:(UITapGestureRecognizer*) tapGesture {
    
    NSLog(@"Double Tap Double Touch= %@",NSStringFromCGPoint([tapGesture locationInView:self.view]));
    
    CGAffineTransform currentTransform = self.testView.transform;
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, 0.8f, 0.8f); // уменьшаем размер
    [UIView animateWithDuration:0.5f
                     animations:^{
                         self.testView.transform = newTransform; //  устанавливаем
                     }];
    self.testViewScale =1.2f;

    
}
//отдельный метод для Pinch

- (void) handlePinch:(UIPinchGestureRecognizer*) pinchGesture {
    
    NSLog(@"handlePinch %1.3f", pinchGesture.scale); // цифра 3 (три) - это 3 (три) знака после точки
    
    //Когда начинаем наш "Pinch" необходимо "Scale" установить в единицу
    
    if (pinchGesture.state == UIGestureRecognizerStateBegan) {
        self.testViewScale = 1.f;
    }
    
    
    //задействуем наш Scale , теперь будем его сохранять
    CGAffineTransform currentTransform = self.testView.transform;
    
    CGFloat newScale = 1.0 + pinchGesture.scale - self.testViewScale;
    
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, newScale, newScale); //одинаковое увеличение по  "x" и "y"
    
    self.testView.transform = newTransform;
    
    self.testViewScale = pinchGesture.scale;
    
    
    
}

//создаем метод для "Rotation"

-(void) handleRotation:(UIRotationGestureRecognizer*) rotetionGesture {
    
    NSLog(@"handleRotation %1.3f", rotetionGesture.rotation);
    
    if (rotetionGesture.state == UIGestureRecognizerStateBegan) { //если текущее состояние = началу вращение,то testViewRotation = "0".
    
        self.testViewRotation = 0;
    }
        
    CGFloat newRotation = rotetionGesture.rotation - self.testViewRotation;
    
    
    CGAffineTransform currentTransform = self.testView.transform; //текущий трансформ ()
    
    CGAffineTransform newTransform = CGAffineTransformRotate(currentTransform, newRotation);
    
    self.testView.transform = newTransform;
    self.testViewRotation = rotetionGesture.rotation;
    
    


}

@end
