//
//  ViewController.m
//  HomeWork Lesson 23 (Gestures)
//
//  Created by Anton Gorlov on 04.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIGestureRecognizerDelegate>

@property (weak,nonatomic) UIView* testView;
@property (weak,nonatomic) UIImageView* testImageView;
@property (assign, nonatomic) float distance;

@property (assign, nonatomic) float testViewScale;//масштаб
@property (assign, nonatomic) float testViewRotation;//вращение


@property (assign, nonatomic)BOOL animation;//анимация вкл\выкл

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     Ученик
     
     1. Добавьте квадратную картинку на вьюху вашего контроллера
     2. Если хотите, можете сделать ее анимированной
     */
    
    UIImageView* view = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMidX(self.view.bounds)-100, CGRectGetMidY(self.view.bounds)-100, 100, 80)];
    
    view.backgroundColor = [UIColor clearColor];
    self.testView = view;
    
    UIImage* image = [UIImage imageNamed:@"Пингвин.jpg"];
    
    NSArray* imageArray = [NSArray arrayWithObjects:image, nil];
    
    view.animationImages = imageArray; //подключаем массив.
    view.animationDuration = 1.f;//продолжительность анимации
    
    [self.view addSubview:view];
    [view startAnimating];
    self.testImageView = view;
    
   
    view.backgroundColor = [UIColor grayColor];
    
    view.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin
                            |UIViewAutoresizingFlexibleLeftMargin
                            |UIViewAutoresizingFlexibleRightMargin
                            |UIViewAutoresizingFlexibleTopMargin;
    
/*
    Студент
    
    3. По тачу анимационно передвигайте картинку со ее позиции в позицию тача
    4. Если я вдруг делаю тач во время анимации, то картинка должна двигаться в новую точку без рывка (как будто она едет себе и все)
*/
    //Tap
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self
                                                                                action:@selector(handleTap:)];
    
    [self.view addGestureRecognizer:tapGesture];
    
   
    
/*
     Мастер
     
     5. Если я делаю свайп вправо, то давайте картинке анимацию поворота по часовой стрелке на 360 градусов
     6. То же самое для свайпа влево, только анимация должна быть против часовой (не забудьте остановить предыдущее кручение)
     7. По двойному тапу двух пальцев останавливайте анимацию
*/
    
    //Swipe left and right
    
    UISwipeGestureRecognizer* leftSwipeGesture = [[UISwipeGestureRecognizer alloc]initWithTarget:self
                                                                                          action:@selector(handleLeftSwipe:)];
    
    
    [self.view addGestureRecognizer:leftSwipeGesture];
    
    UISwipeGestureRecognizer* RightSwipeGesture = [[UISwipeGestureRecognizer alloc]initWithTarget:self
                                                                                          action:@selector(handleRightSwipe:)];
    
    
    [self.view addGestureRecognizer:RightSwipeGesture];
    
    leftSwipeGesture.direction = UISwipeGestureRecognizerDirectionLeft; //виставляем свайп (чтобы xCode мог понять какой правый,какой левый).
    RightSwipeGesture.direction = UISwipeGestureRecognizerDirectionRight;
    
    
    //doubleTap
    
    UITapGestureRecognizer* doubleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                action:@selector(handleDoubleTap:)];
    doubleTapGesture.numberOfTapsRequired = 2; // количество кликов по экрану
    
    [self.view addGestureRecognizer:doubleTapGesture];
    
    //работает одинарный и двойной тап вместе,нужно сделать так,чтобы работали отдельно
    
    [tapGesture requireGestureRecognizerToFail:doubleTapGesture];
    
/*
     Супермен
     
     8. Добавьте возможность зумить и отдалять картинку используя пинч
     9. Добавьте возможность поворачивать картинку используя ротейшн
*/
    //Pinch (зум)
    UIPinchGestureRecognizer* pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self
                                                                                      action:@selector(handlePinch:)];
    
    pinchGesture.delegate = self; // добавляем делегат для того,что одновременно работал  Pinch и Rotation
    
    [self.view addGestureRecognizer:pinchGesture];
    
    //Rotation (вращение)
    
    UIRotationGestureRecognizer* rotationGesture = [[UIRotationGestureRecognizer alloc]initWithTarget:self
                                                                                    action:@selector(handleRotation:)];
    
    rotationGesture.delegate = self;// добавляем делегат для того,что одновременно работал  Pinch и Rotation
    
    [self.view addGestureRecognizer:rotationGesture];
    
    
}
#pragma mark - Methods

- (void) handleTap:(UITapGestureRecognizer*) tapGesture { //уровень СТУДЕНТ
    
    self.testViewScale = 0.8f;
    
    if (tapGesture.state == UIGestureRecognizerStateBegan) { //текущее состояние жеста
        self.distance = 0;
    }
    NSLog(@"Tap %@",NSStringFromCGPoint([tapGesture locationInView:self.view]));
    
    [UIView animateWithDuration:1.3f
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         self.testImageView.center =[tapGesture locationInView:self.view]; 
                     } completion:^(BOOL finished) {
                         
                     }];
}

- (void) handleLeftSwipe:(UISwipeGestureRecognizer*) leftSwipeGesture {

    NSLog(@"Left Swipe");
   
    [UIView animateKeyframesWithDuration:1.3f
                                  delay:0
                                options: UIViewAnimationOptionCurveEaseIn |  UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                                 
                            self.testImageView.transform = CGAffineTransformMakeRotation(-3.14f);//отрицательный поворот на 360 не получился
                                 
                                                              } completion:^(BOOL finished) {
                                 NSLog(@"Left animation ended");
                             }];
}


- (void) handleRightSwipe:(UISwipeGestureRecognizer*) leftRightGesture {
    
    NSLog(@"Right Swipe");
    
    [UIView animateKeyframesWithDuration:1.3f
                                   delay:0
                                 options: UIViewAnimationOptionCurveEaseIn |  UIViewAnimationOptionBeginFromCurrentState
                              animations:^{
                                  self.testImageView.transform = CGAffineTransformMakeRotation(M_PI);
                                  self.testImageView.transform = CGAffineTransformMakeRotation(2 * M_PI);

                               
                                  
                                  
                              } completion:^(BOOL finished) {
                                  NSLog(@"Right animation ended");
                              }];
}

- (void) handleDoubleTap: (UITapGestureRecognizer*) doubleTap {
    
    NSLog(@"Double Tap %@",NSStringFromCGPoint([doubleTap locationInView:self.view]));
    
    self.testViewScale = 1.2f;
    
    if (self.animation) {
        [self.testImageView.layer removeAllAnimations];
        self.animation = NO;
    }else { [self.testImageView startAnimating];
        self.animation = YES;
    }
}
 // Уровень Супермен
- (void) handlePinch:(UIPinchGestureRecognizer*) pinchGesture {

    NSLog(@"Pinch % 1.3f",pinchGesture.scale);
    
    if (pinchGesture.state == UIGestureRecognizerStateBegan) {
        self.testViewScale = 1.f;
    }
    
    //задействуем наш Scale , теперь будем его сохранять
    CGAffineTransform currentTransform = self.testView.transform;
    
    CGFloat newScale = 1.0 + pinchGesture.scale - self.testViewScale;
    
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, newScale, newScale); //одинаковое увеличение по  "x" и "y"
    
    self.testView.transform = newTransform;
    
    self.testViewScale = pinchGesture.scale;

}

- (void) handleRotation: (UIRotationGestureRecognizer*) rotationGesture {

    NSLog(@"handle Rotation %1.3f",rotationGesture.rotation);
    
    if (rotationGesture.state == UIGestureRecognizerStateBegan) {
        self.testViewRotation = 0;
    }
    
    CGFloat newRotation = rotationGesture.rotation - self.testViewRotation;
    
    CGAffineTransform currentTransform = self.testView.transform;
    
    CGAffineTransform newTransform = CGAffineTransformRotate(currentTransform,newRotation );
    
    self.testView.transform = newTransform;
    
    self.testViewRotation = rotationGesture.rotation;
}

#pragma mark- UIGestureRecognizerDelegate 

//запускает Gesture одновременно

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
